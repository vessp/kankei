npm install -g gulp
npm install
gulp