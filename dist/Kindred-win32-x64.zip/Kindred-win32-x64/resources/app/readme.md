-install node.js
-install con emu
	-tasks -> bash gitbash []default task for new console
	-quake style -> []quake
	-size&pos -> fixed
	-colors -> schemes -> twighlight
-clone project (git clone https://github.com/vessp/electron-react-starter.git)
-use gitbash to cd into project folder
-cd C:/Users/shard/Documents/GitHub/electron-react-starter (needs forward slashes)
	C:/Users/jonty.roodnick/Documents/GitHub/electron-react-starter
-sh first-run.sh (after first run can just type 'gulp')

TASK:
> -cur_console:f -cur_console:d:C:\Users\shard\Documents\GitHub\electron-react-starter "C:\Program Files\Git\bin\sh.exe" --login -i


Included libraries you can use:
  -React: https://facebook.github.io/react/
  -FontAwesome: http://fontawesome.io/icons/
  -ESlint
    -sublime linter
    -sublime linter eslint contrib
    -.eslintrc.json
    -http://eslint.org/docs/rules/





GITBASH (command line tool)
CTRL+C 						cancel command
cd c:/users/shard/			c:/users/shard/ (must use /)


